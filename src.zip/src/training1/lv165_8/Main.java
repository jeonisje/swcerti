package training1.lv165_8;

public class Main {
	static int[] arr = new int[150];
	
	
}
