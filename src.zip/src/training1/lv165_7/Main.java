package training1.lv165_7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Main {
	
	static int N = 7;
	static int M = 4;
	static int[][] arr = new int[N][M];
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		StringTokenizer st = new StringTokenizer(br.readLine());
		
		init();
		for(int i=0; i<3; i++) {
			int num = Integer.parseInt(st.nextToken());
			arr[num] = new int[M];
		}
		
		for(int i=0; i<N; i++) {
			for(int j=0; j<M; j++) {
				System.out.print(arr[i][j] + " ");
			}
			System.out.println();
		}
		
	}
	
	static void init() {
		for(int i=0; i<N; i++) {
			for(int j=0; j<M; j++) {
				arr[i][j] = i * M + (j+1);
			}
		}
	}
}
